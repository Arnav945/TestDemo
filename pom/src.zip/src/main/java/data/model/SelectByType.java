package data.model;

public enum SelectByType {
	XPath,
	CssSelector,
	Id,
	Name,
	ClassName, 
	Url
}
