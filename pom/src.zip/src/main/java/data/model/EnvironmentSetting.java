package data.model;

public class EnvironmentSetting {
	public String SystemLevel;
}
